$(document).ready(function(){
	var btn = $(".read");
	var classHandle=true;
	btn.click(function(){
		var readMorebtn = $("#button_cotinue");
		$("#xx").scrollTop();
		if(classHandle)
		{	
			$("#xx").removeClass('main-left-upper',1000,'easeOutBounce');
			$("#xx").addClass('expand-main-left-upper',1000,'easeOutBounce');
		}
		else
		{
			$("#xx").addClass('main-left-upper',1000,'easeOutBounce');
			$("#xx").removeClass('expand-main-left-upper',1000,'easeOutBounce');
		}
		classHandle = !classHandle;
		
		if(readMorebtn.text().match("Continue..."))
			readMorebtn.text("Show Less");
		else if(readMorebtn.text().match("Show Less"))
			readMorebtn.text("Continue...");
	});
	/*
	btn.click(function(){
		var div = $("#xx");
		var readMorebtn = $("#button_cotinue");
		div.toggleClass(function(){
			if($(this).is('main-left-upper'))
			{
				return 'expand-main-left-upper';
			}
			else
			{
				return 'main-left-upper';
			}
		});
		
		if(readMorebtn.text().match("Continue..."))
			readMorebtn.text("Show Less");
		else if(readMorebtn.text().match("Show Less"))
			readMorebtn.text("Continue...");
	});
	*/
	var btn2 = $('.button');
	btn2.click(function(){
		//alert("clicked");
		window.open('http://www.asifnaeem.com','_blank');
	});
});

/*
var handleClick = function(event){
	if(!toggle_expand)
	{
		var div = document.getElementById("xx");
		div.style.height='700px';
		div.style.overflow='auto';
		var buttonLink = document.getElementById("button_cotinue");
		buttonLink.text="Show less";
		toggle_expand = true;
	}
	else
	{
		var div = document.getElementById("xx");
		//var itemToscroll = document.getElementById('headlineText');
		//div.scrollTop = itemToscroll.offsetTop();
		//div.scrollTop();
		div.style.height='350px';
		div.style.overflow='hidden';
		var buttonLink = document.getElementById("button_cotinue");
		buttonLink.text="Continue...";
		toggle_expand = false;
	}
	
};

var toggle_expand = false;
var button = document.querySelector('.read');
button.addEventListener('click', handleClick);
*/
