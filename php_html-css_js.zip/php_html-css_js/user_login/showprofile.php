<?php
	include "header.php";
	if($newUser->getSession()==false)
	{
		header('Location: login.php');
		exit();
	}
	$data = $newUser->getProfileInfo($_SESSION['userid']);
?>
<form action="" method="post">
	<table class="tbl_profile">
		<tr>
			<td>User ID:</td>
			<td><?php echo $data['id'];?></td>
		</tr>
		<tr>
			<td>Full Name:</td>
			<td><input type="text" name="name" value="<?php echo $data['name'];?>"/></td>
		</tr>
		<tr>
			<td>User Name:</td>
			<td><input type="text" name="uname" value="<?php echo $data['user'];?>"/></td>
		</tr>
		<tr>
			<td>Email:</td>
			<td><input type="email" name="email" value="<?php echo $data['email'];?>"/></td>
		</tr>
		<tr>
			<td>Website:</td>
			<td><input type="text" name="web" value="<?php echo $data['web'];?>"/></td>
		</tr>
		<tr>
			<td><input type="submit" name="cancel" value="Cancel"/></td>
			<td><input type="submit" name="Submit" value="Change"/></td>
		</tr>
	</table>
</form>
<?php
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		$id=$_SESSION['userid'];
		$name=$_POST['name'];
		$uname=$_POST['uname'];
		$email=$_POST['email'];
		$web=$_POST['web'];
		$ret = $newUser->updateProfile($id,$name,$uname,$email,$web);
		if($ret)
		{
			echo "<span class='span_class_success'>Data Updated.</span>";
		}
		else
		{
			echo "<span class='span_class'>Data Update Failed.</span>";
		}
	}
?>
<?php
include "footer.php";
?>