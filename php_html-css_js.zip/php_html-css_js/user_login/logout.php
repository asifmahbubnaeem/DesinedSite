<?php
	session_start();
	include "header.php";
	$newUser->logOut();
	header('Location: index.php');
?>