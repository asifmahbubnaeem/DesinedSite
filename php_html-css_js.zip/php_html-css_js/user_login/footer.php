</div>
		<div class="footer clear">
			<h4>Demouserlogin-<a href="http://www.baytal.com">www.baytal.com</a></h4>
		</div>
	</div>

</body>

</html>