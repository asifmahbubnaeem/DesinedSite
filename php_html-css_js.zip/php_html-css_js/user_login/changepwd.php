<?php
	include "header.php";
	if($newUser->getSession()==false)
	{
		header('Location: login.php');
		exit();
	}
?>
<form action="" method="post">
	<table class="tbl_profile">
		<tr>
			<td>Old Password</td>
			<td><input type="password" name="oldpwd" placeholder="Enter Old Password"/></td>
		</tr>
		<tr>
			<td>New Password</td>
			<td><input type="password" name="newpwd" placeholder="Enter New Password"/></td>
		</tr>
		<tr>
			<td>Confirm Password</td>
			<td><input type="password" name="confirmpwd" placeholder="Confirm New Password"/></td>
		</tr>
		<tr>
			<td><input type="reset" value="Clear All"/></td>
			<td><input type="submit" name="chpwd" value="Change Password"/></td>
		</tr>
	</table>
</form>
<?php
if($_SERVER['REQUEST_METHOD']=='POST')
{
	$oldpwd = md5($_POST['oldpwd']);
	$newpwd = md5($_POST['newpwd']);
	$confirmpwd = md5($_POST['confirmpwd']);
	
	if(empty($confirmpwd) or empty($oldpwd) or empty($newpwd))
	{
		echo "<span class='span_class'>Missing Information.</span>";
	}
	else if($newpwd==$confirmpwd)
	{
		$uid = $_SESSION['userid'];
		$ret = $newUser->changepwd($uid,$newpwd,$oldpwd);
		//echo $ret['id'];
		if($ret)
			echo "<span class='span_class_success'>Password changed.</span>";
		else
			echo "<span class='span_class'>You provided wrong password.</span>";
		
	}
	else
	{
		echo "<span class='span_class'>Password confirmation missmatches.</span>";
	}
}
?>
<?php
include "footer.php";
?>