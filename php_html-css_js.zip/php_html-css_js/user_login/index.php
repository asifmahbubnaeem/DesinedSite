<?php
	include "header.php";
	if($newUser->getSession()==false)
	{
		header('Location: login.php');
		exit();
	}
	else
	{ ?>
	<table class="tbl_profile">
	<tr>
		<th>Serial</th>
		<th>User Name</th>
		<th>Profile</th>
	</tr>
	<?php
	$userdata = $newUser->populateData();
	$i=0;
	foreach($userdata as $data)
	{$i+=1;?>
	<tr>
		<td><?php echo $i?></td>
		<td><?php echo $data['user']?></td>
		<td><a href="userprofile.php?id=<?php echo $data['id']?>">View Details</a></td>
	</tr>
	<?php
	}}?>
	</table>
	
<?php
	include "footer.php";
?>