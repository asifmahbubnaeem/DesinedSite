<?php
	include "header.php";
	if($newUser->getSession()==true)
	{
		header('Location: index.php');
		exit();
	}
?>
			<h2>Register</h2>
			<p class="message clear">
				<?php
					if($_SERVER['REQUEST_METHOD']=='POST')
					{
						$user = $_POST['username'];
						$pwd = md5($_POST['pwd']);
						$uname = $_POST['uname'];
						$email = $_POST['email'];
						$web = $_POST['web'];
						
						if(empty($user) or empty($pwd) or empty($uname)
							or empty($email) or empty($web))
						{
							echo "<span class='span_class'>No Field can be empty.</span>";
						}
						else
						{
							$ret=$newUser->registerUser($user,$pwd,$uname,$email,$web);
							if($ret==true)
							{
								echo "<span class='span_class_success'>User Registration Successful.</span>";
							}
							else
							{
								echo "<span class='span_class'>User name and/or email already exist.</span>";
							}
					
						}
					}
				?>
			</p>
			<div class="registration-form">
				<form action="" method="post">
					<table class="tbl">
						<tr>
							<td>Full Name:</td>
							<td><input type="text" name="username" required=1 placeholder="Enter name here"/></td>
						</tr>
						<tr>
							<td>User Name:</td>
							<td><input type="text" name="uname" required=1 placeholder="Enter User name here"/></td>
						</tr>
						<tr>
							<td>Password:</td>
							<td><input type="password" name="pwd" required=1 placeholder="Enter password here"/></td>
						</tr>
						<tr>
							<td>Email:</td>
							<td><input type="email" name="email" placeholder="Enter Email here"/></td>
						</tr>
						<tr>
							<td>Website:</td>
							<td><input type="text" name="web" placeholder="Enter website here"/></td>
						</tr>
						<tr>
							<td><input type="reset" name="Submit" value="Clear"/></td>
							<td><input type="submit" name="Submit" value="Register"/></td>
						</tr>
					</table>
				</form>
			</div>
		</div>
<?php
	include "footer.php";
?>