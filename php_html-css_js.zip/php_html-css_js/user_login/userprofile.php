<?php
	include "header.php";
	if($newUser->getSession()==false)
	{
		header('Location: login.php');
		exit();
	}
	$data = $newUser->getProfileInfo($_GET['id']);
?>
<form action="" method="post">
	<table class="tbl_profile">
		<tr>
			<td>User ID:</td>
			<td><?php echo $data['id'];?></td>
		</tr>
		<tr>
			<td>Full Name:</td>
			<td><?php echo $data['name'];?></td>
		</tr>
		<tr>
			<td>User Name:</td>
			<td><?php echo $data['user'];?></td>
		</tr>
		<tr>
			<td>Email:</td>
			<td><?php echo $data['email'];?></td>
		</tr>
		<tr>
			<td>Website:</td>
			<td><?php echo $data['web'];?></td>
		</tr>
	</table>
</form>
<?php
	include "footer.php";
?>