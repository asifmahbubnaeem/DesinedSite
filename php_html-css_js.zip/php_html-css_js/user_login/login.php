<?php
	include "header.php";
	if($newUser->getSession()==true)
	{
		header('Location: index.php');
		exit();
	}
?>
			<h2>LogIn Form</h2>
			<p class="message clear">
				<?php
					if($_SERVER['REQUEST_METHOD']=='POST')
					{
						$user = $_POST['uname'];
						$pwd = md5($_POST['pwd']);
						
						if(empty($user) or empty($pwd))
						{
							echo "<span class='span_class'>Fields must not be empty.</span>";
						}
						else
						{
							$ret=$newUser->loginUser($user,$pwd);
							if($ret==true)
							{
								echo "<span class='span_class_success'>User LogIn Successful.</span>";
								header('Location: index.php');
								exit();
							}
							else
							{
								echo "<span class='span_class'>Invalid User name and/or password.</span>";
							}
					
						}
					}
				?>
			</p>
			<div class="login-form">
				<form action="" method="post">
					<table class="tbl">
						<tr>
							<td>User Name:</td>
							<td><input type="text" name="uname" required=1 placeholder="Enter User name here"/></td>
						</tr>
						<tr>
							<td>Password:</td>
							<td><input type="password" name="pwd" required=1 placeholder="Enter password here"/></td>
						</tr>
						<tr>
							<td><input type="reset" name="Submit" value="Clear"/></td>
							<td><input type="submit" name="Submit" value="Log in"/></td>
						</tr>
					</table>
				</form>
			</div>
<?php
	include "footer.php";
?>