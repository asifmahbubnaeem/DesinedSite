<?php
	include "RegistrationClass.php";
	$newUser = new RegistrationClass();
?>
<!DOCTYPE html lang="en">
<head>
	<meta charset="UTF-8"/>
	<title>User Login</title>
	<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
	<div class="wrapper clear">
		<div class="header clear">
			<h3>PHP OOP Login-Register System</h3>
		</div>
		<div class="main-menu clear">
			<ul><?php
					session_start();
					if($newUser->getSession())
					{
				?>
				<li><a href="http://localhost/user_login/index.php">Home</a></li>
				<li><a href="http://localhost/user_login/showprofile.php">Show Profile</a></li>
				<li><a href="http://localhost/user_login/changepwd.php">Change Password</a></li>
				<li><a href="http://localhost/user_login/logout.php">Log Out</a></li>
				<?php
					}
					else
					{
				?>
				<li><a href="http://localhost/user_login/login.php">Log in</a></li>
				<li><a href="http://localhost/user_login/registration.php">Register</a></li>
				<?php
					}
				?>
			</ul>
		</div>
	<div class="content clear">