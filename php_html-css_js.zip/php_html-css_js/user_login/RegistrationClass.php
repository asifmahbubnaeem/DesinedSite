<?php
	include "config.php";
	class RegistrationClass
	{
		private $sessionData;
		public function __construct()
		{
				$dbconnect=new DatabaseConnection();
		}
		
		public function registerUser($user,$pwd,$uname,$email,$web)
		{
			global $pdo;
			$query = $pdo->prepare("select id from user where user=?");
			$query->execute(array($uname));
			$row_count = $query->rowCount();
			
			$query = $pdo->prepare("select id from user where email=?");
			$query->execute(array($email));
			$row_count += $query->rowCount();
			if($row_count==0)
			{
				$query=$pdo->prepare("insert into user (name,pwd,user,email,web) values (?,?,?,?,?)");
				$query->execute(array($user,$pwd,$uname,$email,$web));
				return true;
			}
			else
			{
				return false;
			}
		}
		
		public function loginUser($user,$pwd)
		{
			global $pdo;
			$query = $pdo->prepare("select id from user where user=? and pwd=?");
			$query->execute(array($user,$pwd));
			$userdata = $query->fetch();
			$row_count=$query->rowCount();
			if($row_count==0)
				return false;
			else if($row_count==1)
			{
				session_start();
				$_SESSION['login']=true;
				$_SESSION['userid']=$userdata['id'];
				$_SESSION['uname']=$userdata['user'];
				$_SESSION['msg']="Log in successful.";
				return true;
			}
		}
		
		public function getSession()
		{
			return @$_SESSION['login'];
		}
		
		public function logOut()
		{
			$_SESSION['login']=false;
			unset($_SESSION['userid']);
			unset($_SESSION['uname']);
			session_destroy();
		}
		
		public function populateData()
		{
			global $pdo;
			$query = $pdo->prepare("select * from user order by id DESC");
			$query->execute();
			$userdata = $query->fetchAll(PDO::FETCH_ASSOC);
			return $userdata;
		}
		
		public function getSessionData()
		{
			return $sessionData;
		}
		
		public function changepwd($id,$newpwd,$oldpwd)
		{
			global $pdo;
			$query = $pdo->prepare("select pwd from user where id=?");
			$query->execute(array($id));
			$userdata = $query->fetch();
			if($userdata['pwd']==$oldpwd)
			{
				$query = $pdo->prepare("update user set pwd=? where id=?");
				$query->execute(array($newpwd,$id));
				return true;
			}
			else
				return false;
		}
		
		public function getProfileInfo($uid)
		{
			global $pdo;
			$query=$pdo->prepare("select * from user where id=?");
			$query->execute(array($uid));
			$userdata = $query->fetch();
			return $userdata;
		}
		
		public function updateProfile($id,$name,$uname,$email,$web)
		{
			global $pdo;
			//try
			//{
				$query = $pdo->prepare("update user set name=?,
					user=?,email=?,web=? where id=?");
				$query->execute(array($name,$uname,$email,$web,$id));
				return true;
			//}
			//catch(PdoException e)
			//{
				return false;
			//}
			
		}
	}
?>